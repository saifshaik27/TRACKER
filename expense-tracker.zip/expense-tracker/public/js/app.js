const token = localStorage.getItem('token');
if (!token) location.href = 'index.html';

const $ = id => document.getElementById(id);
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const money = n => '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

$('title').textContent = APP_TITLE;
$('foot').textContent = APP_TITLE;
$('who').textContent = 'Hello, ' + (localStorage.getItem('name') || '');
$('logout').onclick = () => { localStorage.clear(); location.href = 'index.html'; };

function flash(text, ok) {
  $('msg').textContent = text; $('msg').className = 'msg ' + (ok ? 'ok' : 'err');
  if (text) setTimeout(() => { $('msg').textContent = ''; }, 4000);
}

async function api(url, method = 'GET', body) {
  const r = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await r.json();
  if (r.status === 401) { localStorage.clear(); location.href = 'index.html'; }
  if (!r.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// period selectors
const now = new Date();
$('month').innerHTML = MONTHS.map((m, i) => `<option value="${i + 1}">${m}</option>`).join('');
$('month').value = now.getMonth() + 1;
$('year').value = now.getFullYear();
$('txDate').value = now.toISOString().slice(0, 10);
const period = () => `month=${$('month').value}&year=${$('year').value}`;

// tabs
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('active', x === b));
  document.querySelectorAll('main section').forEach(s => s.classList.toggle('hidden', s.id !== 'tab-' + b.dataset.tab));
});

// ---------- loaders ----------
async function loadCategories() {
  const cats = await api('/api/categories');
  $('txCat').innerHTML = cats.map(c =>
    `<option value="${c.category_id}">${esc(c.category_name)} (${esc(c.category_type)})</option>`).join('');
  $('catBody').innerHTML = cats.map(c => `
    <tr><td>${esc(c.category_name)}</td><td>${esc(c.category_type)}</td>
    <td><button class="danger" data-del-cat="${c.category_id}">Delete</button></td></tr>`).join('');
}

async function loadTransactions() {
  const type = $('txFilter').value;
  const rows = await api(`/api/transactions?${period()}${type ? '&type=' + type : ''}`);
  $('txBody').innerHTML = rows.length ? rows.map(t => `
    <tr><td>${esc(t.transaction_date)}</td><td>${esc(t.category_name)}</td>
    <td class="${t.transaction_type === 'Income' ? 'income' : 'expense'}">${esc(t.transaction_type)}</td>
    <td>${esc(t.description)}</td><td>${money(t.amount)}</td>
    <td><button class="danger" data-del-tx="${t.transaction_id}">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="6" style="color:var(--muted)">No transactions for this month.</td></tr>';
}

async function loadReports() {
  const r = await api(`/api/reports?${period()}`);
  $('sIncome').textContent = money(r.income);
  $('sExpense').textContent = money(r.expense);
  $('sBalance').textContent = money(r.balance);
  $('sBalance').className = 'value ' + (r.balance >= 0 ? 'income' : 'expense');

  // budget progress
  const bar = $('budgetBar');
  if (r.budget) {
    const pct = r.expense / r.budget * 100;
    bar.style.width = Math.min(pct, 100) + '%';
    bar.className = pct > 100 ? 'over' : pct >= 80 ? 'warn' : '';
    $('budgetText').textContent = `Spent ${money(r.expense)} of ${money(r.budget)} (${pct.toFixed(0)}%)` +
      (pct > 100 ? ' - budget exceeded!' : pct >= 80 ? ' - nearing your limit' : '');
    $('budLimit').value = r.budget;
  } else {
    bar.style.width = '0';
    $('budgetText').textContent = 'No budget set for this month. Set one in the Budget tab.';
    $('budLimit').value = '';
  }

  // spending by category
  const max = Math.max(...r.byCategory.map(c => c.total), 1);
  $('catReport').innerHTML = r.byCategory.length ? r.byCategory.map(c => `
    <div class="bar-row"><span class="name">${esc(c.category_name)}</span>
    <div class="bar-track"><div class="bar-fill" style="width:${c.total / max * 100}%"></div></div>
    <span class="amt">${money(c.total)}</span></div>`).join('')
    : '<p style="color:var(--muted)">No expenses this month.</p>';

  // yearly trend
  const inc = Array(12).fill(0), exp = Array(12).fill(0);
  r.trend.forEach(t => (t.type === 'Income' ? inc : exp)[t.month - 1] = t.total);
  const tmax = Math.max(...inc, ...exp, 1);
  $('trend').innerHTML = MONTHS.map((m, i) => `
    <div class="col"><div class="pair">
      <div class="b i" title="Income ${money(inc[i])}" style="height:${inc[i] / tmax * 100}%"></div>
      <div class="b e" title="Expense ${money(exp[i])}" style="height:${exp[i] / tmax * 100}%"></div>
    </div><small>${m}</small></div>`).join('');
}

const refresh = () => Promise.all([loadTransactions(), loadReports()]).catch(e => flash(e.message));

// ---------- events ----------
$('month').onchange = refresh;
$('year').onchange = refresh;
$('txFilter').onchange = () => loadTransactions().catch(e => flash(e.message));

$('txForm').onsubmit = async e => {
  e.preventDefault();
  try {
    await api('/api/transactions', 'POST', {
      category_id: $('txCat').value, amount: $('txAmt').value,
      description: $('txDesc').value, transaction_date: $('txDate').value
    });
    $('txAmt').value = ''; $('txDesc').value = '';
    flash('Transaction added', true);
    refresh();
  } catch (err) { flash(err.message); }
};

$('catForm').onsubmit = async e => {
  e.preventDefault();
  try {
    await api('/api/categories', 'POST', { category_name: $('catName').value, category_type: $('catType').value });
    $('catName').value = '';
    flash('Category added', true);
    loadCategories();
  } catch (err) { flash(err.message); }
};

$('budForm').onsubmit = async e => {
  e.preventDefault();
  try {
    await api('/api/budget', 'POST', {
      monthly_limit: $('budLimit').value, month: $('month').value, year: $('year').value
    });
    flash('Budget saved', true);
    loadReports();
  } catch (err) { flash(err.message); }
};

document.addEventListener('click', async e => {
  const tx = e.target.dataset.delTx, cat = e.target.dataset.delCat;
  try {
    if (tx && confirm('Delete this transaction?')) {
      await api('/api/transactions/' + tx, 'DELETE'); flash('Transaction deleted', true); refresh();
    }
    if (cat && confirm('Delete this category?')) {
      await api('/api/categories/' + cat, 'DELETE'); flash('Category deleted', true); loadCategories();
    }
  } catch (err) { flash(err.message); }
});

loadCategories().then(refresh).catch(e => flash(e.message));
