# Personal Expense Tracker Management System - Shaik Abdul Saif

A mini project to track daily income and expenses. Users can register/login, add transactions,
categorize them, set monthly budgets and view spending reports.

**Tech stack:** HTML, CSS, JavaScript (frontend) · Express.js (backend) · MySQL (database)

## Features
- User registration and login (bcrypt-hashed passwords, JWT sessions)
- Add / delete income and expense transactions
- Custom categories (default ones created on registration)
- Monthly budget with progress bar and over-budget warning
- Reports: totals, spending by category, yearly income vs expense chart

## Database tables
| Table | Fields |
|---|---|
| users | user_id (PK), name, email, password |
| categories | category_id (PK), user_id (FK), category_name, category_type |
| transactions | transaction_id (PK), user_id (FK), category_id (FK), amount, transaction_type, description, transaction_date |
| budgets | budget_id (PK), user_id (FK), monthly_limit, month, year |

## Setup
1. Install Node.js and MySQL.
2. Create the database: `mysql -u root -p < schema.sql`
3. Install dependencies: `npm install`
4. Copy `.env.example` to `.env` and set your MySQL password and a random `JWT_SECRET`.
5. Start: `npm start`, then open http://localhost:3000

## Project structure
```
server.js          Express API + static file server
schema.sql         MySQL tables
public/index.html  Login / register page
public/app.html    Main application
public/css/        Styles
public/js/         config.js (project title/name), auth.js, app.js
```

The author name shown in the title is set in `public/js/config.js`.
