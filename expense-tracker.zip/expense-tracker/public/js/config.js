// Owner name is added to the project title everywhere in the app.
// Change it here if it is not spelled the way you want.
const OWNER_NAME = 'Shaik Abdul Saif';
const APP_TITLE = 'Personal Expense Tracker Management System - ' + OWNER_NAME;
document.title = APP_TITLE;
