const $ = (id) => document.getElementById(id);
let mode = "login", currentUser = null, categories = [], transactions = [];
const money = n => "₹" + Number(n || 0).toLocaleString("en-IN", {minimumFractionDigits:2, maximumFractionDigits:2});
const today = () => new Date().toISOString().slice(0,10);
async function api(url, options={}) {
  const res = await fetch("/api"+url, {headers:{"Content-Type":"application/json"}, ...options});
  const data = await res.json().catch(()=>({message:"Unexpected server response."}));
  if (!res.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}
function toast(message) { const el=$("toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2600); }
function setAuthMode(next) {
  mode=next; $("loginTab").classList.toggle("active",mode==="login"); $("registerTab").classList.toggle("active",mode==="register");
  $("nameGroup").classList.toggle("hidden",mode!=="register"); $("name").required=mode==="register";
  $("authSubmit").textContent=mode==="login"?"Login":"Create account"; $("authMessage").textContent="";
}
$("loginTab").onclick=()=>setAuthMode("login"); $("registerTab").onclick=()=>setAuthMode("register");
$("authForm").onsubmit=async e=>{
  e.preventDefault(); $("authMessage").textContent="";
  try {
    const body={email:$("email").value,password:$("password").value};
    if(mode==="register") body.name=$("name").value;
    const result=await api("/"+mode,{method:"POST",body:JSON.stringify(body)});
    currentUser=result.user; showApp();
  } catch(err){$("authMessage").textContent=err.message;}
};
async function init(){
  try { const d=await api("/me"); if(d.user){currentUser=d.user;showApp();} } catch(e){}
}
function showApp(){
  $("authView").classList.add("hidden"); $("appView").classList.remove("hidden");
  $("userName").textContent=currentUser.name; $("welcomeName").textContent=currentUser.name.split(" ")[0];
  loadAll();
}
$("logoutBtn").onclick=async()=>{await api("/logout",{method:"POST"});location.reload();};
document.querySelectorAll(".nav-link").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>showPage(b.dataset.go));
function showPage(name){
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $(name+"Page").classList.remove("hidden");
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  $("pageTitle").textContent=({dashboard:"Dashboard",transactions:"Transactions",categories:"Categories",reports:"Reports",budget:"Monthly budget"})[name];
  if(name==="reports") loadReports();
}
async function loadAll(){
  try{
    [categories,transactions]=await Promise.all([api("/categories"),api("/transactions")]);
    renderCategories(); renderTransactions(); await Promise.all([loadSummary(),loadReports()]);
  }catch(e){toast(e.message);}
}
async function loadSummary(){
  const s=await api("/summary");
  $("totalIncome").textContent=money(s.income);$("totalExpense").textContent=money(s.expense);$("totalBalance").textContent=money(s.balance);
  $("totalBudget").textContent=s.budget?money(s.budget):"Not set";
  $("budgetHint").textContent=s.budget?`${Math.max(0,s.budget-s.expense).toLocaleString("en-IN",{style:"currency",currency:"INR"})} remaining`:"Set a spending limit";
  $("budgetSpent").innerHTML=`${money(s.expense)} <small>/ ${money(s.budget)}</small>`;
  const pct=s.budget?Math.min(100,s.expense/s.budget*100):0;$("budgetProgress").style.width=pct+"%";
  $("budgetProgress").style.background=pct>100?"#e05a65":"#159b72";
  $("budgetStatus").textContent=s.budget?(pct>100?"You have exceeded your budget.":`${pct.toFixed(1)}% of your monthly budget used.`):"Set a budget to begin tracking.";
}
function renderTransactions(){
  const rows=transactions.map(t=>`<tr><td>${escapeHtml(t.description||"—")}</td><td>${escapeHtml(t.category_name)}</td><td>${formatDate(t.transaction_date)}</td><td><span class="pill ${t.transaction_type}">${t.transaction_type}</span></td><td class="amount-${t.transaction_type}">${t.transaction_type==="income"?"+":"−"}${money(t.amount)}</td><td class="actions"><button data-edit="${t.transaction_id}">Edit</button><button class="delete" data-delete="${t.transaction_id}">Delete</button></td></tr>`).join("");
  $("transactionRows").innerHTML=rows||'<tr><td colspan="6" class="muted">No transactions yet. Add your first transaction.</td></tr>';
  $("recentRows").innerHTML=transactions.slice(0,5).map(t=>`<tr><td>${escapeHtml(t.description||"—")}</td><td>${escapeHtml(t.category_name)}</td><td>${formatDate(t.transaction_date)}</td><td><span class="pill ${t.transaction_type}">${t.transaction_type}</span></td><td class="amount-${t.transaction_type}">${t.transaction_type==="income"?"+":"−"}${money(t.amount)}</td></tr>`).join("")||'<tr><td colspan="5" class="muted">No recent transactions.</td></tr>';
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openTransaction(Number(b.dataset.edit)));
  document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deleteTransaction(Number(b.dataset.delete)));
}
function renderCategories(){
  $("categoryList").innerHTML=categories.map(c=>`<span class="category-chip">${escapeHtml(c.category_name)} <small>${c.category_type}</small></span>`).join("")||"No categories yet.";
}
function fillCategoryOptions(type, selected){
  const list=categories.filter(c=>c.category_type===type);
  $("txCategory").innerHTML=list.map(c=>`<option value="${c.category_id}" ${Number(selected)===Number(c.category_id)?"selected":""}>${escapeHtml(c.category_name)}</option>`).join("");
}
$("txType").onchange=()=>fillCategoryOptions($("txType").value);
function openTransaction(id){
  const t=transactions.find(x=>x.transaction_id===id);
  $("transactionForm").reset(); $("editId").value=t?t.transaction_id:"";
  $("dialogTitle").textContent=t?"Edit transaction":"Add transaction";
  $("txType").value=t?t.transaction_type:"expense";
  fillCategoryOptions($("txType").value,t?t.category_id:null);
  $("txAmount").value=t?t.amount:""; $("txDate").value=t?t.transaction_date:today();
  $("txDescription").value=t?t.description||"":"";
  $("transactionDialog").showModal();
}
$("newTransaction").onclick=()=>openTransaction(null); $("quickAdd").onclick=()=>openTransaction(null);
$("closeDialog").onclick=()=>$("transactionDialog").close();
$("transactionForm").onsubmit=async e=>{
  e.preventDefault();
  const id=$("editId").value;
  const body={category_id:$("txCategory").value,amount:$("txAmount").value,transaction_type:$("txType").value,transaction_date:$("txDate").value,description:$("txDescription").value};
  try{
    await api("/transactions"+(id?"/"+id:""),{method:id?"PUT":"POST",body:JSON.stringify(body)});
    $("transactionDialog").close();toast(id?"Transaction updated.":"Transaction added.");await loadAll();
  }catch(err){toast(err.message);}
};
async function deleteTransaction(id){
  if(!confirm("Delete this transaction?"))return;
  try{await api("/transactions/"+id,{method:"DELETE"});toast("Transaction deleted.");await loadAll();}catch(e){toast(e.message);}
}
$("categoryForm").onsubmit=async e=>{
  e.preventDefault();
  try{await api("/categories",{method:"POST",body:JSON.stringify({category_name:$("categoryName").value,category_type:$("categoryType").value})});$("categoryForm").reset();categories=await api("/categories");renderCategories();toast("Category added.");}
  catch(err){toast(err.message);}
};
async function loadReports(){
  const rows=await api("/reports");const max=Math.max(...rows.map(r=>Number(r.total)),1);
  $("reportList").innerHTML=rows.map(r=>`<div class="report-row"><span>${escapeHtml(r.category_name)} <span class="pill ${r.transaction_type}">${r.transaction_type}</span></span><strong>${money(r.total)}</strong><div class="report-bar"><span style="width:${Number(r.total)/max*100}%"></span></div></div>`).join("")||'<p class="muted">No transactions recorded this month.</p>';
}
$("budgetForm").onsubmit=async e=>{
  e.preventDefault();
  try{await api("/budgets",{method:"POST",body:JSON.stringify({monthly_limit:$("budgetAmount").value})});toast("Monthly budget saved.");await loadSummary();}
  catch(err){toast(err.message);}
};
function formatDate(value){if(!value)return "—";const d=new Date(value+"T00:00:00");return d.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"});}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
init();