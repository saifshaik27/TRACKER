require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "expense_tracker",
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const requireAuth = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ message: "Please log in." });
  next();
};

async function addDefaultCategories(userId) {
  const defaults = [
    ["Salary", "income"], ["Business", "income"], ["Other income", "income"],
    ["Food", "expense"], ["Transport", "expense"], ["Shopping", "expense"],
    ["Bills", "expense"], ["Health", "expense"], ["Education", "expense"],
    ["Entertainment", "expense"], ["Other expense", "expense"]
  ];
  for (const [name, type] of defaults) {
    await pool.execute(
      "INSERT IGNORE INTO categories (user_id, category_name, category_type) VALUES (?, ?, ?)",
      [userId, name, type]
    );
  }
}

app.post("/api/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: "Enter your name, email and a password of at least 6 characters." });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.execute(
      "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
      [name.trim(), email.trim().toLowerCase(), hash]
    );
    await addDefaultCategories(result.insertId);
    req.session.user = { user_id: result.insertId, name: name.trim(), email: email.trim().toLowerCase() };
    res.json({ message: "Account created successfully.", user: req.session.user });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "This email is already registered." });
    console.error(err); res.status(500).json({ message: "Registration failed. Check the server/database." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.execute("SELECT * FROM users WHERE email = ?", [(email || "").trim().toLowerCase()]);
    if (!rows.length || !(await bcrypt.compare(password || "", rows[0].password)))
      return res.status(401).json({ message: "Invalid email or password." });
    const u = rows[0];
    req.session.user = { user_id: u.user_id, name: u.name, email: u.email };
    res.json({ message: "Login successful.", user: req.session.user });
  } catch (err) { console.error(err); res.status(500).json({ message: "Login failed." }); }
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ message: "Logged out." })));
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/categories", requireAuth, async (req, res) => {
  const [rows] = await pool.execute(
    "SELECT category_id, category_name, category_type FROM categories WHERE user_id = ? ORDER BY category_type, category_name",
    [req.session.user.user_id]);
  res.json(rows);
});

app.post("/api/categories", requireAuth, async (req, res) => {
  try {
    const { category_name, category_type } = req.body;
    if (!category_name || !["income", "expense"].includes(category_type))
      return res.status(400).json({ message: "Enter a category name and valid type." });
    const [r] = await pool.execute(
      "INSERT INTO categories (user_id, category_name, category_type) VALUES (?, ?, ?)",
      [req.session.user.user_id, category_name.trim(), category_type]);
    res.status(201).json({ category_id: r.insertId, message: "Category added." });
  } catch (e) { res.status(400).json({ message: "Category already exists or could not be added." }); }
});

app.get("/api/transactions", requireAuth, async (req, res) => {
  const [rows] = await pool.execute(
    `SELECT t.transaction_id, t.category_id, t.amount, t.transaction_type,
            t.description, t.transaction_date, c.category_name
     FROM transactions t JOIN categories c ON c.category_id=t.category_id
     WHERE t.user_id=? ORDER BY t.transaction_date DESC, t.transaction_id DESC`,
    [req.session.user.user_id]);
  res.json(rows);
});

app.post("/api/transactions", requireAuth, async (req, res) => {
  try {
    const { category_id, amount, transaction_type, description, transaction_date } = req.body;
    const value = Number(amount);
    if (!category_id || !Number.isFinite(value) || value <= 0 ||
        !["income", "expense"].includes(transaction_type) || !transaction_date)
      return res.status(400).json({ message: "Please enter valid transaction details." });
    const [cats] = await pool.execute(
      "SELECT category_id FROM categories WHERE category_id=? AND user_id=? AND category_type=?",
      [category_id, req.session.user.user_id, transaction_type]);
    if (!cats.length) return res.status(400).json({ message: "Choose a category matching the transaction type." });
    const [r] = await pool.execute(
      `INSERT INTO transactions
       (user_id, category_id, amount, transaction_type, description, transaction_date)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [req.session.user.user_id, category_id, value, transaction_type, description || "", transaction_date]);
    res.status(201).json({ transaction_id: r.insertId, message: "Transaction saved." });
  } catch (e) { console.error(e); res.status(500).json({ message: "Could not save transaction." }); }
});

app.put("/api/transactions/:id", requireAuth, async (req, res) => {
  try {
    const { category_id, amount, transaction_type, description, transaction_date } = req.body;
    const value = Number(amount), uid = req.session.user.user_id;
    if (!category_id || !Number.isFinite(value) || value <= 0 ||
        !["income", "expense"].includes(transaction_type) || !transaction_date)
      return res.status(400).json({ message: "Invalid transaction details." });
    const [cats] = await pool.execute(
      "SELECT category_id FROM categories WHERE category_id=? AND user_id=? AND category_type=?",
      [category_id, uid, transaction_type]);
    if (!cats.length) return res.status(400).json({ message: "Invalid category." });
    const [r] = await pool.execute(
      `UPDATE transactions SET category_id=?, amount=?, transaction_type=?, description=?, transaction_date=?
       WHERE transaction_id=? AND user_id=?`,
      [category_id, value, transaction_type, description || "", transaction_date, req.params.id, uid]);
    if (!r.affectedRows) return res.status(404).json({ message: "Transaction not found." });
    res.json({ message: "Transaction updated." });
  } catch (e) { res.status(500).json({ message: "Update failed." }); }
});

app.delete("/api/transactions/:id", requireAuth, async (req, res) => {
  const [r] = await pool.execute("DELETE FROM transactions WHERE transaction_id=? AND user_id=?",
    [req.params.id, req.session.user.user_id]);
  if (!r.affectedRows) return res.status(404).json({ message: "Transaction not found." });
  res.json({ message: "Transaction deleted." });
});

app.get("/api/summary", requireAuth, async (req, res) => {
  const uid = req.session.user.user_id;
  const [rows] = await pool.execute(
    `SELECT
      COALESCE(SUM(CASE WHEN transaction_type='income' THEN amount ELSE 0 END),0) AS income,
      COALESCE(SUM(CASE WHEN transaction_type='expense' THEN amount ELSE 0 END),0) AS expense
     FROM transactions WHERE user_id=? AND MONTH(transaction_date)=MONTH(CURRENT_DATE())
       AND YEAR(transaction_date)=YEAR(CURRENT_DATE())`, [uid]);
  const [budget] = await pool.execute(
    "SELECT monthly_limit FROM budgets WHERE user_id=? AND month=MONTH(CURRENT_DATE()) AND year=YEAR(CURRENT_DATE())",
    [uid]);
  const income = Number(rows[0].income), expense = Number(rows[0].expense);
  res.json({ income, expense, balance: income - expense, budget: budget.length ? Number(budget[0].monthly_limit) : 0 });
});

app.get("/api/reports", requireAuth, async (req, res) => {
  const uid = req.session.user.user_id;
  const [rows] = await pool.execute(
    `SELECT c.category_name, t.transaction_type, SUM(t.amount) AS total
     FROM transactions t JOIN categories c ON c.category_id=t.category_id
     WHERE t.user_id=? AND MONTH(t.transaction_date)=MONTH(CURRENT_DATE())
       AND YEAR(t.transaction_date)=YEAR(CURRENT_DATE())
     GROUP BY c.category_name, t.transaction_type ORDER BY total DESC`, [uid]);
  res.json(rows);
});

app.post("/api/budgets", requireAuth, async (req, res) => {
  const limit = Number(req.body.monthly_limit), now = new Date();
  if (!Number.isFinite(limit) || limit <= 0) return res.status(400).json({ message: "Enter a valid budget amount." });
  await pool.execute(
    `INSERT INTO budgets (user_id, monthly_limit, month, year) VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE monthly_limit=VALUES(monthly_limit)`,
    [req.session.user.user_id, limit, now.getMonth() + 1, now.getFullYear()]);
  res.json({ message: "Monthly budget saved." });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Expense Tracker running at http://localhost:${PORT}`));