# SHAIK ABDUL SAIF – PERSONAL EXPENSE TRACKER MANAGEMENT SYSTEM

A full-stack mini-project built with HTML, CSS, JavaScript, Node.js, Express.js and MySQL.

## Features
- User registration and login (passwords hashed with bcrypt)
- Add, view, edit and delete income/expense transactions
- Default and custom transaction categories
- Monthly budget setting and spending progress
- Monthly income, expense and balance dashboard
- Category-wise monthly report
- User-specific data protected by login sessions

## Project structure
```text
shaik-abdul-saif-expense-tracker/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── database.sql
├── server.js
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

## Requirements
- Node.js (LTS)
- MySQL Server and MySQL Workbench
- VS Code (recommended)

## Setup and run (Windows)
1. Extract the ZIP and open the project folder in VS Code.
2. Start MySQL Server.
3. Open MySQL Workbench, create/open a SQL tab, paste the contents of `database.sql`, and click the lightning icon to execute.
4. In VS Code terminal, run:
   ```bash
   npm install
   ```
5. Copy `.env.example` to a new file named `.env`.
6. Edit `.env` and enter your MySQL password. If your MySQL root account has no password, leave `DB_PASSWORD=` blank.
7. Start the application:
   ```bash
   npm start
   ```
8. Open `http://localhost:3000` in your browser.
9. Register a new account and start adding transactions.

## Database tables
- `users`: user account details
- `categories`: income and expense categories belonging to a user
- `transactions`: each money transaction, linked to a user and category
- `budgets`: one monthly spending limit per user per month

All primary keys are auto-incrementing. Foreign keys maintain relationships and cascade user-owned data when an account is deleted.

## Upload to GitHub
1. Create a new empty repository on GitHub named `shaik-abdul-saif-expense-tracker`.
2. Open this folder in VS Code and sign in to GitHub.
3. Open Terminal and run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Personal Expense Tracker"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/shaik-abdul-saif-expense-tracker.git
   git push -u origin main
   ```
4. Replace `YOUR-USERNAME` with your actual GitHub username.

## Important security notes
- Never upload `.env` or real database passwords to GitHub. `.gitignore` excludes `.env`.
- This is a learning/demo project. For production deployment, use a persistent session store, HTTPS, secure cookies, CSRF protection, input rate limiting and stronger deployment configuration.
- The app expects the MySQL database to be created before starting the server.
