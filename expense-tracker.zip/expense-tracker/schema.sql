-- Personal Expense Tracker Management System - database schema
CREATE DATABASE IF NOT EXISTS expense_tracker;
USE expense_tracker;

-- TABLE 1: users
CREATE TABLE IF NOT EXISTS users (
  user_id  INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(100) NOT NULL,
  email    VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- TABLE 2: categories
CREATE TABLE IF NOT EXISTS categories (
  category_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  category_name VARCHAR(100) NOT NULL,
  category_type VARCHAR(20)  NOT NULL,          -- 'Income' or 'Expense'
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- TABLE 3: transactions
CREATE TABLE IF NOT EXISTS transactions (
  transaction_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL,
  category_id      INT NOT NULL,
  amount           DECIMAL(10,2) NOT NULL,
  transaction_type VARCHAR(20)  NOT NULL,       -- 'Income' or 'Expense'
  description      VARCHAR(255),
  transaction_date DATE NOT NULL,
  FOREIGN KEY (user_id)     REFERENCES users(user_id)           ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(category_id)  ON DELETE RESTRICT
);

-- TABLE 4: budgets
CREATE TABLE IF NOT EXISTS budgets (
  budget_id     INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  monthly_limit DECIMAL(10,2) NOT NULL,
  month         INT NOT NULL,
  year          INT NOT NULL,
  UNIQUE KEY uq_user_month (user_id, month, year),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);
