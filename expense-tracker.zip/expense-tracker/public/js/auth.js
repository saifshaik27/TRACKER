document.getElementById('title').textContent = APP_TITLE;
if (localStorage.getItem('token')) location.href = 'app.html';

const $ = id => document.getElementById(id);
const msg = (t, ok) => { $('msg').textContent = t; $('msg').className = 'msg ' + (ok ? 'ok' : 'err'); };

$('toReg').onclick = () => { $('loginForm').classList.add('hidden'); $('regForm').classList.remove('hidden'); msg(''); };
$('toLogin').onclick = () => { $('regForm').classList.add('hidden'); $('loginForm').classList.remove('hidden'); msg(''); };

async function post(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  return { ok: r.ok, data: await r.json() };
}

$('loginForm').onsubmit = async e => {
  e.preventDefault();
  const { ok, data } = await post('/api/login', { email: $('lEmail').value, password: $('lPass').value });
  if (!ok) return msg(data.error);
  localStorage.setItem('token', data.token);
  localStorage.setItem('name', data.name);
  location.href = 'app.html';
};

$('regForm').onsubmit = async e => {
  e.preventDefault();
  const { ok, data } = await post('/api/register', {
    name: $('rName').value, email: $('rEmail').value, password: $('rPass').value
  });
  if (!ok) return msg(data.error);
  $('regForm').reset();
  $('toLogin').click();
  msg('Registered! Please login.', true);
};
