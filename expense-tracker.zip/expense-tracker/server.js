require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'expense_tracker',
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true
});
const SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

// ---------- helpers ----------
const wrap = fn => (req, res) =>
  fn(req, res).catch(err => {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  });

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Please log in' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Session expired, please log in again' });
  }
}

const TYPES = ['Income', 'Expense'];
const periodOf = q => {
  const now = new Date();
  const month = parseInt(q.month) || now.getMonth() + 1;
  const year = parseInt(q.year) || now.getFullYear();
  return { month, year };
};

// ---------- auth ----------
app.post('/api/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'All fields are required' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  const [exists] = await pool.query('SELECT user_id FROM users WHERE email = ?', [email]);
  if (exists.length) return res.status(409).json({ error: 'Email already registered' });
  const hash = await bcrypt.hash(password, 10);
  const [r] = await pool.query('INSERT INTO users (name, email, password) VALUES (?,?,?)', [name, email, hash]);
  const defaults = [
    ['Salary', 'Income'], ['Other Income', 'Income'],
    ['Food', 'Expense'], ['Transport', 'Expense'], ['Rent', 'Expense'],
    ['Shopping', 'Expense'], ['Bills', 'Expense'], ['Entertainment', 'Expense']
  ];
  await pool.query('INSERT INTO categories (user_id, category_name, category_type) VALUES ?',
    [defaults.map(d => [r.insertId, d[0], d[1]])]);
  res.json({ message: 'Registered successfully' });
}));

app.post('/api/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
  if (!rows.length || !(await bcrypt.compare(password || '', rows[0].password)))
    return res.status(401).json({ error: 'Invalid email or password' });
  const u = rows[0];
  const token = jwt.sign({ user_id: u.user_id, name: u.name }, SECRET, { expiresIn: '8h' });
  res.json({ token, name: u.name });
}));

// ---------- categories ----------
app.get('/api/categories', auth, wrap(async (req, res) => {
  const [rows] = await pool.query(
    'SELECT * FROM categories WHERE user_id = ? ORDER BY category_type, category_name', [req.user.user_id]);
  res.json(rows);
}));

app.post('/api/categories', auth, wrap(async (req, res) => {
  const { category_name, category_type } = req.body;
  if (!category_name || !TYPES.includes(category_type))
    return res.status(400).json({ error: 'Name and valid type (Income/Expense) required' });
  await pool.query('INSERT INTO categories (user_id, category_name, category_type) VALUES (?,?,?)',
    [req.user.user_id, category_name.trim(), category_type]);
  res.json({ message: 'Category added' });
}));

app.delete('/api/categories/:id', auth, wrap(async (req, res) => {
  try {
    const [r] = await pool.query('DELETE FROM categories WHERE category_id = ? AND user_id = ?',
      [req.params.id, req.user.user_id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'Category not found' });
    res.json({ message: 'Category deleted' });
  } catch (e) {
    if (e.code === 'ER_ROW_IS_REFERENCED_2')
      return res.status(409).json({ error: 'Category has transactions; delete them first' });
    throw e;
  }
}));

// ---------- transactions ----------
app.get('/api/transactions', auth, wrap(async (req, res) => {
  const { month, year } = periodOf(req.query);
  let sql = `SELECT t.*, c.category_name FROM transactions t
             JOIN categories c ON c.category_id = t.category_id
             WHERE t.user_id = ? AND MONTH(t.transaction_date) = ? AND YEAR(t.transaction_date) = ?`;
  const params = [req.user.user_id, month, year];
  if (TYPES.includes(req.query.type)) { sql += ' AND t.transaction_type = ?'; params.push(req.query.type); }
  sql += ' ORDER BY t.transaction_date DESC, t.transaction_id DESC';
  const [rows] = await pool.query(sql, params);
  res.json(rows);
}));

app.post('/api/transactions', auth, wrap(async (req, res) => {
  const { category_id, amount, description, transaction_date } = req.body;
  const amt = parseFloat(amount);
  if (!category_id || !(amt > 0) || !transaction_date)
    return res.status(400).json({ error: 'Category, positive amount and date are required' });
  const [cat] = await pool.query('SELECT category_type FROM categories WHERE category_id = ? AND user_id = ?',
    [category_id, req.user.user_id]);
  if (!cat.length) return res.status(400).json({ error: 'Invalid category' });
  await pool.query(
    `INSERT INTO transactions (user_id, category_id, amount, transaction_type, description, transaction_date)
     VALUES (?,?,?,?,?,?)`,
    [req.user.user_id, category_id, amt, cat[0].category_type, (description || '').slice(0, 255), transaction_date]);
  res.json({ message: 'Transaction added' });
}));

app.delete('/api/transactions/:id', auth, wrap(async (req, res) => {
  const [r] = await pool.query('DELETE FROM transactions WHERE transaction_id = ? AND user_id = ?',
    [req.params.id, req.user.user_id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Transaction not found' });
  res.json({ message: 'Transaction deleted' });
}));

// ---------- budgets ----------
app.get('/api/budget', auth, wrap(async (req, res) => {
  const { month, year } = periodOf(req.query);
  const [rows] = await pool.query('SELECT * FROM budgets WHERE user_id = ? AND month = ? AND year = ?',
    [req.user.user_id, month, year]);
  res.json(rows[0] || null);
}));

app.post('/api/budget', auth, wrap(async (req, res) => {
  const { month, year } = periodOf(req.body);
  const limit = parseFloat(req.body.monthly_limit);
  if (!(limit > 0)) return res.status(400).json({ error: 'Enter a positive budget amount' });
  await pool.query(
    `INSERT INTO budgets (user_id, monthly_limit, month, year) VALUES (?,?,?,?)
     ON DUPLICATE KEY UPDATE monthly_limit = VALUES(monthly_limit)`,
    [req.user.user_id, limit, month, year]);
  res.json({ message: 'Budget saved' });
}));

// ---------- reports ----------
app.get('/api/reports', auth, wrap(async (req, res) => {
  const { month, year } = periodOf(req.query);
  const uid = req.user.user_id;
  const [tot] = await pool.query(
    `SELECT transaction_type AS type, SUM(amount) AS total FROM transactions
     WHERE user_id = ? AND MONTH(transaction_date) = ? AND YEAR(transaction_date) = ?
     GROUP BY transaction_type`, [uid, month, year]);
  const income = Number((tot.find(t => t.type === 'Income') || {}).total || 0);
  const expense = Number((tot.find(t => t.type === 'Expense') || {}).total || 0);
  const [byCat] = await pool.query(
    `SELECT c.category_name, SUM(t.amount) AS total FROM transactions t
     JOIN categories c ON c.category_id = t.category_id
     WHERE t.user_id = ? AND t.transaction_type = 'Expense'
       AND MONTH(t.transaction_date) = ? AND YEAR(t.transaction_date) = ?
     GROUP BY c.category_id, c.category_name ORDER BY total DESC`, [uid, month, year]);
  const [trend] = await pool.query(
    `SELECT MONTH(transaction_date) AS month, transaction_type AS type, SUM(amount) AS total
     FROM transactions WHERE user_id = ? AND YEAR(transaction_date) = ?
     GROUP BY MONTH(transaction_date), transaction_type`, [uid, year]);
  const [b] = await pool.query('SELECT monthly_limit FROM budgets WHERE user_id = ? AND month = ? AND year = ?',
    [uid, month, year]);
  res.json({
    income, expense, balance: income - expense,
    budget: b.length ? Number(b[0].monthly_limit) : null,
    byCategory: byCat.map(r => ({ category_name: r.category_name, total: Number(r.total) })),
    trend: trend.map(r => ({ month: r.month, type: r.type, total: Number(r.total) }))
  });
}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Personal Expense Tracker Management System - Shaik Abdul Saif running at http://localhost:${PORT}`));
